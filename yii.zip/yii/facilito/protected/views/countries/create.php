<title>Pedidos | Elio's Grill & Bakery™</title>

<?php

class UsersController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}
}

$this->breadcrumbs=array(
	'Pedidos',
	'Pida a domicilio',
);

$this->menu=array(
	array('label'=>'Lista de Pedidos', 'url'=>array('index')),
);

#If you would like to order a home-cooked meal according to your location, to celebrate your special event, or just to sit and have coffee without leaving the #comfort of your own home or home, please fill out the following home delivery form. Thank you.
?>	

<h1>Pida a Domicilio</h1>

<p>
Si desea ordenar una comida casera según su ubicación, para celebrar su evento especial, o simplemente para sentarse y tomar un café sin salir de la comodidad de su hogar o casa, por favor llene el siguiente formulario de entrega a domicilio. Gracias.
</p>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'countries-form',
	'enableAjaxValidation'=>false,
	'enableClientValidation'=>true,
	'clientOptions'=>array(
	'validateOnSubmit'=>true,
	),
)); ?>

	<?php echo $form->errorSummary($model,null,null,array("class"=>"alert alert-error")); ?>

	<left><div class="span9"><img src="http://i.imgur.com/bfNLHRF.png"></div></left>

<p class="note">Los campos con <span class="required">*</span> son obligatorios.</p>

<div>
<?php echo $form->labelEx($model,'Platillo <span class="required">*</span>'); ?>
<?php echo $form->dropDownList($model,'food',array(
	'Arroz con pollo y ensalada'=>"Arroz con pollo y ensalada",
	'Arroz con carne y tajadas'=>"Arroz con carne y tajadas",
	'Arroz con lentejas y queso'=>"Arroz con lentejas y queso",
	'Pasta con carne y parmesano'=>"Pasta con carne y parmesano",
	'Sopa de mariscos con arroz'=>"Sopa de mariscos con arroz",
	'Arroz con carne strangonofe'=>"Arroz con carne strangonofe",
	'Pastelitos rellenos de carne'=>"Pastelitos rellenos de carne",
	'Pastelitos rellenos de pollo'=>"Pastelitos rellenos de pollo",
	'Pastelitos rellenos de queso'=>"Pastelitos rellenos de queso",
	'Pastelitos rellenos de jamón'=>"Pastelitos rellenos de jamón",
	'Empanadas de cazón'=>"Empanadas de cazón",
	'Macarrón con queso'=>"Macarrón con queso",
)); ?>
<?php echo $form->error($model,"food");?>
</div>

<div>
<?php echo $form->labelEx($model,'Especificaciones'); ?>
<?php echo $form->textField($model,"specifications",array('placeholder'=>"Your specifications here",'title'=>"Your specifications here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,"specifications");?>
</div>

<div>
<?php echo $form->labelEx($model,'Nombre <span class="required">*</span>'); ?>
<?php echo $form->textField($model,"name",array('placeholder'=>"Your name here",'title'=>"Your name here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,"name");?>
</div>

<div>
<?php echo $form->labelEx($model,'Direcci&oacute;n <span class="required">*</span>'); ?>
<?php echo $form->textField($model,"address",array('placeholder'=>"Your address here",'title'=>"Your address here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,"address");?>
</div>

<div>
<?php echo $form->labelEx($model,'Estado'); ?>
<?php echo $form->textField($model,"status",array('placeholder'=>"Your state here",'title'=>"Your state here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,"status");?>
</div>

<div>
<?php echo $form->labelEx($model,'Tel&eacute;fono <span class="required">*</span>'); ?>
<?php echo $form->textField($model,'phone',array('placeholder'=>"Your phone here",'pattern'=>"^[a-zA-Z0-9.!#$%&amp;'*+/=?^_`{|}~-]+-[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$",'required'=>"", 
'title'=>"0123-1234567",'type'=>"text",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,"phone");?>
</div>

</div>

<?php echo CHtml::submitButton("Ordenar",array("class"=>"btn btn-primary btn-large"));?>
<?php $this->endWidget();?>