<table>
	<tr>
		<th style="background-color: #555;color:#fff">ID</th>
		<th style="background-color: #555;color:#fff">PLATILLO</th>
		<th style="background-color: #555;color:#fff">ESPECIFICACIONES</th>
		<th style="background-color: #555;color:#fff">NOMBRE</th>
		<th style="background-color: #555;color:#fff">DIRECCION</th>
		<th style="background-color: #555;color:#fff">TELEFONO</th>
	</tr>
<?php foreach($model as $data):?>
	<tr>
		<td style="background-color: #F5F5F5;color:#555"><b><?php echo $data->id?></b></td>
		<td style="background-color: #F5F5F5;color:#555"><b><?php echo $data->food?></b></td>
		<td style="background-color: #F5F5F5;color:#555"><b><?php echo $data->specifications?></b></td>
		<td style="background-color: #F5F5F5;color:#555"><b><?php echo $data->name?></b></td>
		<td style="background-color: #F5F5F5;color:#555"><b><?php echo $data->address?></b></td>
		<td style="background-color: #F5F5F5;color:#555"><b><?php echo $data->phone?></b></td>
	</tr>
<?php endforeach;?>
</table>