<table>
	<tr>
		<th style="background-color: #555;color:#fff">ID</th>
		<th style="background-color: #555;color:#fff">PLATILLO</th>
		<th style="background-color: #555;color:#fff">ESPECIFICACIONES</th>
		<th style="background-color: #555;color:#fff">NOMBRE</th>
		<th style="background-color: #555;color:#fff">DIRECCION</th>
		<th style="background-color: #555;color:#fff">TELEFONO</th>
	</tr>
<?php foreach($model as $data):?>
	<tr>
		<td><?php echo $data->id?></td>
		<td><?php echo $data->food?></td>
		<td><?php echo $data->specifications?></td>
		<td><?php echo $data->name?></td>
		<td><?php echo $data->address?></td>
		<td><?php echo $data->phone?></td>
	</tr>
<?php endforeach;?>
</table>