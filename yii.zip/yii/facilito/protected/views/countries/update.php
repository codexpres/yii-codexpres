<title>Pedidos | Elio's Grill & Bakery™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Pedidos',
	$model->id,
);
?>

<?php  
$this->menu=array(
	array('label'=>'Lista de Pedidos', 'url'=>array('index')),
	array('label'=>'Pida a Domicilio', 'url'=>array('create')),
	array('label'=>'Ver Pedido', 'url'=>array("view","id"=>$model->id)),
	array('label'=>'Borrar Pedido', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	);
?>

<h1>Actualizar el Pedido #<?php echo $model->id?></h1>
<?php $form=$this->beginWidget("CActiveForm");?>

<br>
<b>Platillo<br>
<?php echo $form->dropDownList($model,'food',array(
	'Arroz con pollo y ensalada'=>"Arroz con pollo y ensalada",
	'Arroz con carne y tajadas'=>"Arroz con carne y tajadas",
	'Arroz con lentejas y queso'=>"Arroz con lentejas y queso",
	'Pasta con carne y parmesano'=>"Pasta con carne y parmesano",
	'Sopa de mariscos con arroz'=>"Sopa de mariscos con arroz",
	'Arroz con carne strangonofe'=>"Arroz con carne strangonofe",
	'Pastelitos rellenos de carne'=>"Pastelitos rellenos de carne",
	'Pastelitos rellenos de pollo'=>"Pastelitos rellenos de pollo",
	'Pastelitos rellenos de queso'=>"Pastelitos rellenos de queso",
	'Pastelitos rellenos de jamón'=>"Pastelitos rellenos de jamón",
	'Empanadas de cazón'=>"Empanadas de cazón",
	'Macarrón con queso'=>"Macarrón con queso",
)); ?>
<?php echo $form->error($model,"food");?>
<br>
<b>Especificaciones<br>
<?php echo $form->textField($model,'specifications',array('placeholder'=>"Your specifications here",'title'=>"Your specifications here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,"specifications");?>
<br>
<b>Nombre</b><br>
<?php echo $form->textField($model,'name',array('placeholder'=>"Your name here",'title'=>"Your name here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,"name");?>
<br>
<b>Dirección</b><br>
<?php echo $form->textField($model,'address',array('placeholder'=>"Your address here",'title'=>"Your address here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,"address");?>
<br>
<b>Teléfono</b><br>
<?php echo $form->textField($model,'phone',array('placeholder'=>"Your phone here",'pattern'=>"^[a-zA-Z0-9.!#$%&amp;'*+/=?^_`{|}~-]+-[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$",'required'=>"", 
'title'=>"0123-1234567",'type'=>"text",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,"phone");?>
<br>
<b>Estado</b><br>
<?php echo $form->textField($model,'status',array('placeholder'=>"Your state here",'title'=>"Your state here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,"status");?>
<br>
<?php echo CHtml::submitButton("Actualizar",array("class"=>"btn btn-primary btn-large"));?>
<?php $this->endWidget();?>