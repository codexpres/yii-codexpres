<title>Pedidos | Elio's Grill & Bakery™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Pedidos',
	$model->id,
);
?>

<?php  
$this->menu=array(
	array('label'=>'Lista de Pedidos', 'url'=>array('index')),
	array('label'=>'Pida a Domicilio', 'url'=>array('create')),
	array('label'=>'Actualizar Pedido', 'url'=>array("update","id"=>$model->id)),
	array('label'=>'Borrar Pedido', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	'htmlOptions'=>array('label'=>'Imprimir', "url"=>"javascript:print()", array("class"=>"btn")),
	);
?>

<h1>Ver detalles del Pedido #<?php echo $model->id; ?></h1> 

<table class="table table-inverse table-bordered">
	<tr>
		<td><strong>ID</strong></td>
		<td><?php echo $model->id?></td>
	</tr>
	<tr>
		<td><strong>Platillo</strong></td>
		<td><?php echo $model->food?></td>	
	</tr>
	<tr>
		<td><strong>Especificaciones</strong></td>
		<td><?php echo $model->specifications?></td>	
	</tr>
	<tr>
		<td><strong>Nombre</strong></td>
		<td><?php echo $model->name?></td>
	</tr>
	<tr>
		<td><strong>Dirección</strong></td>
		<td><?php echo $model->address?></td>
	</tr>
	<tr>
		<td><strong>Teléfono</strong></td>
		<td><?php echo $model->phone?></td>
	</tr>
	<tr>
		<td><strong>Estado</strong></td>
		<td><span class="label label-<?php echo $model->status==1?"info":"warning";?>"><?php echo $model->status==1?"Preparado":"No preparado";?></span>
		<?php
			#echo $model->status 
		?></td>
	</tr>
	
</table>