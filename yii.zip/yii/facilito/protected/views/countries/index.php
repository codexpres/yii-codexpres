<title>Pedidos | Elio's Grill & Bakery™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Pida a Domilicio',
	'Pedidos',
);

$this->menu=array(
array('label'=>'Pida a Domilicio', 'url'=>array('/countries/create')),
#array('label'=>'Manage Deliveries', 'url'=>array('/countries/admin')),
);
?>

<h1>Pedidos <?php echo CHtml::link("Exportar a Excel",array("index","excel"=>1),array("class"=>"btn"));?></h1>

<?php foreach($countries as $data):?>

<div class="media">
	<div class="media-body">
		<h3 class="media-heading">
			<?php echo CHtml::encode($data->getAttributeLabel('id')); ?>: <?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
			<?php echo CHtml::encode($data->name); ?> <small><b><?php echo CHtml::encode($data->phone); ?></b></small> <small><?php echo CHtml::encode($data->address); ?></small> 
		</h3>
		<h6><b><a href="<?php echo $this->createUrl("enabled",array("id"=>$data->id));?>">
		<span class="label label-<?php echo $data->status==1?"info":"warning";?>">
			<?php echo $data->status==1?"Preparado":"No preparado";?>
		</span>
	</a><?php echo CHtml::encode($data->food); ?> | <?php echo CHtml::encode($data->specifications); ?></b></h6>		

		<p style="text-align: justify;">
		<u>Por motivos de seguridad:</u>
		<li>Una vez que el usuario o cliente haya realizado la petición del platillo, asegúrese de comprobar los datos del cliente, así como la petición de dicho platillo realizado por el mismo.</li>
		<li>Asegúrese de explicarle bien al detalle que si no se presenta persona alguna al momento de hacer la entrega a domicilio, automáticamente el platillo podrá ser devuelto y el monto cobrado al remintente sin previo aviso.</li>
		<li>Para cancelar un platillo: 5000 BsF x Platillo.</li>
		Y recuerde, trate a los clientes como a usted le gustaría ser tratado.</p>

	</div>
</div>

<ul><small><?php echo CHtml::link("Ver",array("view","id"=>$data->id));?> | <?php echo CHtml::link("Actualizar",array("update","id"=>$data->id));?></small></ul>

<hr>

<?php endforeach;?>