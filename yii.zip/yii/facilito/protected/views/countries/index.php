<title>Pedidos | Elio's Grill & Bakery™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Pida a Domilicio',
	'Pedidos',
);

$this->menu=array(
array('label'=>'Pida a Domilicio', 'url'=>array('/countries/create')),
#array('label'=>'Manage Deliveries', 'url'=>array('/countries/admin')),
);
?>

<h1>Pedidos <?php echo CHtml::link("Exportar a Excel",array("index","excel"=>1),array("class"=>"btn"));?></h1>

<?php foreach($countries as $data):?>

<div class="media">
	<div class="media-body">
		<h3 class="media-heading">
			<?php echo CHtml::encode($data->getAttributeLabel('id')); ?>: <?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
			<?php echo CHtml::encode($data->name); ?> <small><b><?php echo CHtml::encode($data->phone); ?></b></small> <small><?php echo CHtml::encode($data->address); ?></small> 
		</h3>
		<h6><b><a href="<?php echo $this->createUrl("enabled",array("id"=>$data->id));?>">
		<span class="label label-<?php echo $data->status==1?"info":"warning";?>">
			<?php echo $data->status==1?"Preparado":"No preparado";?>
		</span>
	</a><?php echo CHtml::encode($data->food); ?> | <?php echo CHtml::encode($data->specifications); ?></b></h6><p style="text-align: justify;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu libero a libero scelerisque rhoncus. Cras finibus velit non dignissim finibus. In hac habitasse platea dictumst. Suspendisse egestas placerat lacus tristique sodales. Donec eget eros sodales, malesuada sapien non, malesuada diam. In eu pretium lorem. Maecenas condimentum ac sapien a molestie.</p>
	</div>
</div>

<ul><small><?php echo CHtml::link("Ver",array("view","id"=>$data->id));?> | <?php echo CHtml::link("Actualizar",array("update","id"=>$data->id));?></small></ul>

<hr>

<?php endforeach;?>