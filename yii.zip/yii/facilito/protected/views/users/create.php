<title>Reservar una Mesa | Elio's Grill & Bakery™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Reservaciones',
	'Reserve una Mesa',
);

$this->menu=array(
	array('label'=>'Lista de Reservaciones', 'url'=>array('index')),
	array('label'=>'Gestionar Reservaciones', 'url'=>array('admin')),
);
?>

<h1>Reserve una Mesa</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>