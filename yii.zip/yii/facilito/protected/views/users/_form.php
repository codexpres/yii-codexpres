<?php
/* @var $this UsersController */
/* @var $model Users */
/* @var $form CActiveForm */



#If you want to reserve a table to celebrate your special event or simply to sit and have a drink from the comfort of our own establishment, please fill out the #following table reservations form. Thank you.
?>
<p>
Si desea reservar una mesa para celebrar su evento especial o simplemente para sentarse y tomar una copa en la comodidad de nuestro propio establecimiento, por favor llene el siguiente formulario de reservas de la mesa. Gracias.
</p>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'users-form',
	'enableAjaxValidation'=>false,
	'enableClientValidation'=>true,
	'clientOptions'=>array(
	'validateOnSubmit'=>true,
	),
)); ?>

	<?php echo $form->errorSummary($model,null,null,array("class"=>"alert alert-error")); ?>

<left><div class="span9"><img src="http://i.imgur.com/uuddw2e.gif"></div></left>

<p class="note">Los campos con <span class="required">*</span> son obligatorios.</p>

	<div>
		<?php echo $form->labelEx($model,'Nombre <span class="required">*</span>'); ?>
		<?php echo $form->textField($model,'name',array('title'=>"Your name here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'name'); ?>
	</div>

	<div>
		<?php echo $form->labelEx($model,'Fecha <span class="required">*</span>'); ?>
		<?php $this->widget("zii.widgets.jui.CJuiDatePicker",array(
			"attribute"=>"date",
			"model"=>$model,
			"language"=>"es",
			"options"=>array(
				"dateFormat"=>"yy-mm-dd"
				)	
		)); ?>
		<?php echo $form->error($model,'date'); ?>
	</div>

	<div>
		<?php echo $form->labelEx($model,'Hora <span class="required">*</span>'); ?>
		<?php echo $form->dropDownList($model,'time',array(
	'00:00:00'=>"00:00:00",
	'00:30:00'=>"00:30:00",
	'01:00:00'=>"01:00:00",
	'01:30:00'=>"01:30:00",
	'02:00:00'=>"02:00:00",
	'02:30:00'=>"02:30:00",
	'03:00:00'=>"03:00:00",
	'03:30:00'=>"03:30:00",
	'04:00:00'=>"04:00:00",
	'04:30:00'=>"04:30:00",
	'05:00:00'=>"05:00:00",
	'05:30:00'=>"05:30:00",
	'06:00:00'=>"06:00:00",
	'06:30:00'=>"06:30:00",
	'07:00:00'=>"07:00:00",
	'07:30:00'=>"07:30:00",
	'08:00:00'=>"08:00:00",
	'08:30:00'=>"08:30:00",
	'09:00:00"'=>"09:00:00",
	'09:30:00'=>"09:30:00",
	'10:00:00'=>"10:00:00",
	'10:30:00'=>"10:30:00",
	)); ?>
		<?php echo $form->error($model,'time'); ?>
	</div>

	<div>
		<?php echo $form->labelEx($model,'Email <span class="required">*</span>'); ?>
		<?php echo $form->textField($model,'email',array('pattern'=>"^[a-zA-Z0-9.!#$%&amp;'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$",'required'=>"", 
		'title'=>"nombre@ejemplo.com",'type'=>"text",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'email'); ?>
	</div>

	<div>
		<?php echo $form->labelEx($model,'Tel&eacute;fono <span class="required">*</span>'); ?>
		<?php echo $form->textField($model,'phone',array('pattern'=>"^[a-zA-Z0-9.!#$%&amp;'*+/=?^_`{|}~-]+-[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$",'required'=>"", 
		'title'=>"0123-1234567",'type'=>"text",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'phone'); ?>
	</div>

	<div>
		<?php echo $form->labelEx($model,'Miembros <span class="required">*</span>'); ?>
		<?php echo $form->dropDownList($model,'members',array(
	'1'=>"1",
	'2'=>"2",
	'3'=>"3",
	'4'=>"4",
	'5'=>"5",
	'6'=>"6",
	'7'=>"7",
	'8'=>"8",
	'9'=>"9",
	'10'=>"10",
	'11'=>"11",
	'12'=>"12",
	'13'=>"13",
	'14'=>"14",
	'15'=>"15",
	'16'=>"16",
	'17'=>"17",
	'18'=>"18",
	'19'=>"19",
	'20'=>"20",
	)); ?>
		<?php echo $form->error($model,'members'); ?>
	</div>

	<div class="buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Reservar' : 'Save', array("class"=>"btn btn-primary btn-large")); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->