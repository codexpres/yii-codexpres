<title>Reservaciones | Elio's Grill & Bakery™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Reservaciones',
	$model->id,
);

$this->menu=array(
	array('label'=>'Lista de Reservaciones', 'url'=>array('index')),
	array('label'=>'Reserve una Mesa', 'url'=>array('create')),
	array('label'=>'Ver Reservación', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Borrar Reservación', 'url'=>array('delete')),
	array('label'=>'Gestionar Reservaciones', 'url'=>array('admin')),
);
?>

<h1>Actualizar la Reservación #<?php echo $model->id; ?></h1>
<?php $form=$this->beginWidget("CActiveForm");?>

<br>
<b>Nombre<br>
<?php echo $form->textField($model,"name");?>
<?php echo $form->error($model,"name");?>
<br>
<b>Fecha<br>
<?php echo $form->error($model,"date");?>
		<?php $this->widget("zii.widgets.jui.CJuiDatePicker",array(
			"attribute"=>"date",
			"model"=>$model,
			"language"=>"es",
			"options"=>array(
				"dateFormat"=>"yy-mm-dd"
				)	
		)); ?>
<br>
<b>Hora</b><br>
		<?php echo $form->dropDownList($model,'time',array(
	'00:00:00'=>"00:00:00",
	'00:30:00'=>"00:30:00",
	'01:00:00'=>"01:00:00",
	'01:30:00'=>"01:30:00",
	'02:00:00'=>"02:00:00",
	'02:30:00'=>"02:30:00",
	'03:00:00'=>"03:00:00",
	'03:30:00'=>"03:30:00",
	'04:00:00'=>"04:00:00",
	'04:30:00'=>"04:30:00",
	'05:00:00'=>"05:00:00",
	'05:30:00'=>"05:30:00",
	'06:00:00'=>"06:00:00",
	'06:30:00'=>"06:30:00",
	'07:00:00'=>"07:00:00",
	'07:30:00'=>"07:30:00",
	'08:00:00'=>"08:00:00",
	'08:30:00'=>"08:30:00",
	'09:00:00"'=>"09:00:00",
	'09:30:00'=>"09:30:00",
	'10:00:00'=>"10:00:00",
	'10:30:00'=>"10:30:00",
	)); ?>
<?php echo $form->error($model,"time");?>
<br>
<b>Email</b><br>
<?php echo $form->textField($model,'email',array('pattern'=>"^[a-zA-Z0-9.!#$%&amp;'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$",'required'=>"", 
'title'=>"nombre@ejemplo.com",'type'=>"text",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,"email");?>
<br>
<b>Teléfono</b><br>
<?php echo $form->textField($model,'phone',array('pattern'=>"^[a-zA-Z0-9.!#$%&amp;'*+/=?^_`{|}~-]+-[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$",'required'=>"", 
'title'=>"0123-1234567",'type'=>"text",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,"phone");?>
<br>
<b>Miembros</b><br>
<?php echo $form->dropDownList($model,'members',array(
	'1'=>"1",
	'2'=>"2",
	'3'=>"3",
	'4'=>"4",
	'5'=>"5",
	'6'=>"6",
	'7'=>"7",
	'8'=>"8",
	'9'=>"9",
	'10'=>"10",
	'11'=>"11",
	'12'=>"12",
	'13'=>"13",
	'14'=>"14",
	'15'=>"15",
	'16'=>"16",
	'17'=>"17",
	'18'=>"18",
	'19'=>"19",
	'20'=>"20",
	)); ?>
<?php echo $form->error($model,"members");?>
<br>

<?php echo CHtml::submitButton("Actualizar",array("class"=>"btn btn-primary btn-large"));?>
<?php $this->endWidget();?>