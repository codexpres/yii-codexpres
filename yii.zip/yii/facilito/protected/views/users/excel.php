<table>
	<tr>
		<th style="background-color: #555;color:#fff">ID</th>
		<th style="background-color: #555;color:#fff">NOMBRE</th>
		<th style="background-color: #555;color:#fff">TELEFONO</th>
		<th style="background-color: #555;color:#fff">EMAIL</th>
		<th style="background-color: #555;color:#fff">FECHA</th>
		<th style="background-color: #555;color:#fff">HORA</th>
		<th style="background-color: #555;color:#fff">MIEMBROS</th>
	</tr>
<?php foreach($model as $data):?>
	<tr>
		<td><?php echo $data->id?></td>
		<td><?php echo $data->name?></td>
		<td><?php echo $data->phone?></td>
		<td><?php echo $data->email?></td>
		<td><?php echo $data->date?></td>
		<td><?php echo $data->time?></td>
		<td><?php echo $data->members?></td>
	</tr>
<?php endforeach;?>
</table>