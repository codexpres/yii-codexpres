<table>
	<tr>
		<th style="background-color: #555;color:#fff">ID</th>
		<th style="background-color: #555;color:#fff">NOMBRE</th>
		<th style="background-color: #555;color:#fff">TELEFONO</th>
		<th style="background-color: #555;color:#fff">EMAIL</th>
		<th style="background-color: #555;color:#fff">FECHA</th>
		<th style="background-color: #555;color:#fff">HORA</th>
		<th style="background-color: #555;color:#fff">MIEMBROS</th>
	</tr>
<?php foreach($model as $data):?>
	<tr>
		<td style="background-color: #F5F5F5;color:#555"><b><?php echo $data->id?></b></td>
		<td style="background-color: #F5F5F5;color:#555"><b><?php echo $data->name?></b></td>
		<td style="background-color: #F5F5F5;color:#555"><b><?php echo $data->phone?></b></td>
		<td style="background-color: #F5F5F5;color:#555"><b><?php echo $data->email?></b></td>
		<td style="background-color: #F5F5F5;color:#555"><b><?php echo $data->date?></b></td>
		<td style="background-color: #F5F5F5;color:#555"><b><?php echo $data->time?></b></td>
		<td style="background-color: #F5F5F5;color:#555"><b><?php echo $data->members?></b></td>
	</tr>
<?php endforeach;?>
</table>