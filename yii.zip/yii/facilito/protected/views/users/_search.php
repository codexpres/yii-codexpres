<?php
/* @var $this UsersController */
/* @var $model Users */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div>
		<?php echo $form->label($model,'id'); ?>
		<?php echo $form->textField($model,'id',array('title'=>"Your id here",'placeholder'=>"Your id here")); ?>
	</div>

	<div>
		<?php echo $form->label($model,'name'); ?>
		<?php echo $form->textField($model,'name',array('title'=>"Your name here",'placeholder'=>"Your name here",'size'=>60,'maxlength'=>128)); ?>
	</div>

	<div>
		<?php echo $form->label($model,'phone'); ?>
		<?php echo $form->textField($model,'phone',array('title'=>"Your phone here",'placeholder'=>"Your phone here",'size'=>60,'maxlength'=>128)); ?>
	</div>

	<div>
		<?php echo $form->label($model,'email'); ?>
		<?php echo $form->textField($model,'email',array('title'=>"Your email here",'placeholder'=>"Your email here",'size'=>60,'maxlength'=>128)); ?>
	</div>

	<div class="buttons">
		<?php echo CHtml::submitButton('Buscar',array("class"=>"btn btn-primary btn-large")); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->