<?php
/* @var $this UsersController */
/* @var $model Users */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div>
		<?php echo $form->label($model,'id'); ?>
		<?php echo $form->textField($model,'id',array('placeholder'=>"Your id here",'title'=>"Your id here",'size'=>60,'maxlength'=>128)); ?>
	</div>

	<div>
		<?php echo $form->label($model,'name'); ?>
		<?php echo $form->textField($model,'name',array('placeholder'=>"Your name here",'title'=>"Your name here",'size'=>60,'maxlength'=>128)); ?>
	</div>

	<div>
		<?php echo $form->label($model,'phone'); ?>
		<?php echo $form->textField($model,'phone',array('placeholder'=>"Your phone here",'title'=>"Your phone here",'size'=>60,'maxlength'=>128)); ?>
	</div>

	<div>
		<?php echo $form->label($model,'email'); ?>
		<?php echo $form->textField($model,'email',array('placeholder'=>"Your email here",'title'=>"Your email here",'size'=>60,'maxlength'=>128)); ?>
	</div>

	<div class="buttons">
		<?php echo CHtml::submitButton('Buscar',array("class"=>"btn btn-primary btn-large")); ?> | <input type="reset" value="Borrar" class="btn btn-primary btn-large">
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->