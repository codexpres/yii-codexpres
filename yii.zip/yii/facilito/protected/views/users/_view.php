<title>Reservaciones | Elio's Grill & Bakery™</title>

<?php
/* @var $this UsersController */
/* @var $data Users */
?>

<?php #foreach($users as $data):?>

<div class="media">
	<div class="media-body">
		<h3 class="media-heading">
			<?php echo CHtml::encode($data->getAttributeLabel('id')); ?>: <?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
			<?php echo CHtml::encode($data->name); ?> <small><b><?php echo CHtml::encode($data->phone); ?></b></small> <small><?php echo CHtml::encode($data->email); ?></small> 
		</h3>
		<h6><b>MIEMBROS: <?php echo CHtml::encode($data->members); ?> | <?php echo CHtml::encode($data->date); ?> | <?php echo CHtml::encode($data->time); ?></b></h6><p style="text-align: justify;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc eu libero a libero scelerisque rhoncus. Cras finibus velit non dignissim finibus. In hac habitasse platea dictumst. Suspendisse egestas placerat lacus tristique sodales. Donec eget eros sodales, malesuada sapien non, malesuada diam. In eu pretium lorem. Maecenas condimentum ac sapien a molestie.</p>
	</div>
</div>

<ul><small><?php echo CHtml::link("Ver",array("view","id"=>$data->id));?> | <?php echo CHtml::link("Actualizar",array("update","id"=>$data->id));?></small></ul>

<hr>

<?php #endforeach;?>