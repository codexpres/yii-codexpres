<title>Reservaciones | Elio's Grill & Bakery™</title>

<?php
/* @var $this UsersController */
/* @var $data Users */
?>

<?php #foreach($users as $data):?>

<div class="media">
	<div class="media-body">
		<h3 class="media-heading">
			<?php echo CHtml::encode($data->getAttributeLabel('id')); ?>: <?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
			<?php echo CHtml::encode($data->name); ?> <small><b><?php echo CHtml::encode($data->phone); ?></b></small> <small><?php echo CHtml::encode($data->email); ?></small> 
		</h3>
		<h6><b>MIEMBROS: <?php echo CHtml::encode($data->members); ?> | <?php echo CHtml::encode($data->date); ?> | <?php echo CHtml::encode($data->time); ?></b></h6>

		<p style="text-align: justify;">
		<u>Por motivos de seguridad:</u>
		<li>Una vez que el usuario o cliente haya realizado la reservación, asegúrese de comprobar los datos del cliente, así como dicha reservación realizada por el mismo.</li>
		<li>Asegúrese de explicarle bien al detalle que si no se presenta el dia y la fecha que realizó la reservación, automáticamente la misma podrá ser eliminada sin previo aviso.</li>
		<li>Para cancelar una reservación: 1000 BsF x Persona.</li>
		Y recuerde, trate a los clientes como a usted le gustaría ser tratado.</p>

	</div>
</div>

<ul><small><?php echo CHtml::link("Ver",array("view","id"=>$data->id));?> | <?php echo CHtml::link("Actualizar",array("update","id"=>$data->id));?></small></ul>

<hr>

<?php #endforeach;?>