<title>Reservaciones | Elio's Grill & Bakery™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Reservaciones',
	$model->id,
);

$this->menu=array(
	array('label'=>'Lista de Reservaciones', 'url'=>array('index')),
	array('label'=>'Reserve una Mesa', 'url'=>array('create')),
	array('label'=>'Actualizar Reservación', 'url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Borrar Reservación', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Gestionar Reservaciones', 'url'=>array('admin')),
	'htmlOptions'=>array('label'=>'Imprimir', "url"=>"javascript:print()", array("class"=>"btn")),
);
?>

<h1>Ver la Reservación #<?php echo $model->id; ?></h1>

<table class="table table-inverse table-bordered">
	<tr>
		<td><strong>ID</strong></td>
		<td><?php echo $model->id?></td>
	</tr>
	<tr>
		<td><strong>Nombre</strong></td>
		<td><?php echo $model->name?></td>	
	</tr>
	<tr>
		<td><strong>Fecha</strong></td>
		<td><?php echo $model->date?></td>	
	</tr>
	<tr>
		<td><strong>Hora</strong></td>
		<td><?php echo $model->time?></td>
	</tr>
	<tr>
		<td><strong>Email</strong></td>
		<td><?php echo $model->email?></td>
	</tr>
	<tr>
		<td><strong>Teléfono</strong></td>
		<td><?php echo $model->phone?></td>
	</tr>
	<tr>
		<td><strong>Miembros</strong></td>
		<td><?php echo $model->members?></td>
	</tr>
	
</table>
