<title>Reservaciones | Elio's Grill & Bakery™</title>

<?php

class CountriesController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}
}

/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Reservaciones',
	'Gestionar Reservaciones',
);

$this->menu=array(
	array('label'=>'Lista de Reservaciones', 'url'=>array('index')),
	array('label'=>'Reserve una Mesa', 'url'=>array('create')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#users-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>Gestionar Reservaciones</h1>

<p>
Opcionalmente puede introducir un operador de comparación (<b>&lt;</b>, <b>&lt;=</b>, <b>&gt;</b>, <b>&gt;=</b>, <b>&lt;&gt;</b>
or <b>=</b>) al principio de cada uno de los valores de búsqueda para especificar cómo debe realizarse la comparación.
</p>

<?php echo CHtml::link('Búsqueda Avanzada','#',array('class'=>'search-button')); ?>
<div class="search-form" style="display:none">
<?php $this->renderPartial('_search',array(
	'model'=>$model,
)); ?>
</div><!-- search-form -->

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'users-grid',
	'htmlOptions'=>array("class"=>"table table-inverse"),
	'pager'=>array("htmlOptions"=>array("class"=>"pagination")),
	'dataProvider'=>$model->search(),
	#'filter'=>$model,
	'columns'=>array(
		'id',
		'name',
		'date',
		'time',
		'email',
		'phone',
		'members',
		array(
			'class'=>'CButtonColumn',
			#'visible'=>false,
			)
	),
)); ?>