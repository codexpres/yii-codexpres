<title>Login | Elio's Grill & Bakery™</title>

<?php
/* @var $this SiteController */
/* @var $model LoginForm */
/* @var $form CActiveForm  */

$this->pageTitle=Yii::app()->name . ' - Login';
$this->breadcrumbs=array(
	'Iniciar Sesión',
);
?>

<h1>Inicie sesión</h1>

<p>Por favor llene el siguiente formulario con sus credenciales de acceso:</p>

<div class="form">
<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'login-form',
	'enableClientValidation'=>true,
	'clientOptions'=>array(
		'validateOnSubmit'=>true,
	),
)); ?>

<?php #echo $form->errorSummary($model,null,null,array("class"=>"alert alert-error")); ?>

 <left><div class="span3"><img src="http://i.imgur.com/k8m2a3z.gif"></div></left>

	<p class="note">Los campos con <span class="required">*</span> son obligatorios.</p>

	<div>
		<?php echo $form->labelEx($model,'Nombre <span class="required">*</span>'); ?>
		<?php echo $form->textField($model,'username',array('placeholder'=>"Your username here",'title'=>"Your username here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'username'); ?>
	</div>

	<div>
		<?php echo $form->labelEx($model,'Password <span class="required">*</span>'); ?>
		<?php echo $form->passwordField($model,'password',array('placeholder'=>"Your password here",'title'=>"Your password here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'password'); ?>
		<p class="hint">

		<br>

			<small>¿No posee una cuenta o no está registrado en el sistema? <u><a href="http://www.eliosgrillandbakery.tk/yii/facilito/site/registro.html" target="_blank" class="info">Regístrese gratis ahora.</a></u></small><!-- Sugerencia: Puede iniciar sesión con: <kbd>demo</kbd>/<kbd>demo</kbd> o <kbd>admin</kbd>/<kbd>admin</kbd> si así lo desea. -->
		</p>
	</div>

	<div class="rememberMe">
	<label class="checkbox">
		<?php echo $form->checkBox($model,'rememberMe'); ?>
		<?php echo $form->label($model,'rememberMe'); ?>
		<?php echo $form->error($model,'rememberMe'); ?>
	</label>
	</div>

	<p></p>
	
	<div class="buttons">
		<?php echo CHtml::submitButton('Iniciar',array("class"=>"btn btn-primary btn-large")); ?> | <input type="reset" value="Borrar" class="btn btn-primary btn-large"><!-- o <div class="fb-login-button" data-max-rows="1" data-size="large" data-button-type="login_with" data-show-faces="false" data-auto-logout-link="false" data-use-continue-as="false"></div>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/es_LA/sdk.js#xfbml=1&version=v2.10&appId=334277390331354";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script> -->

	</div>

<?php $this->endWidget(); ?>
</div><!-- form -->