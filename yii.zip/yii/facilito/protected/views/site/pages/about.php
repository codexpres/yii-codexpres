<title>Acerca | Elio's Grill & Bakery™</title>

<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'Acerca de nosotros',
);
?>
<h1>Acerca de Nosotros</h1>

<h3>Ubicación</h3>
<p style="text-align: justify;">
A escasos 200 metros de la estación del metro Bello Monte, la empresa o local de comida marítima Ellio’s Grill & Bakery™ está ubicado en la calle Marilla de Colinas de Los Chaguaramos, entre la quinta transversal, al lado del Centro Polo. Cuenta con un amplio y seguro estacionamiento propio con Valet Parking.<br>
<br>
Al llegar a la entrada, un pequeño pero clásico recibidor acoge a los clientes con unos grandes, hermosos e históricos cuadros pintorescos de la época precolombina. El suelo está rodeado con elegantes, cómodos y modernos sofás alrededor de las paredes. Acompañando el lugar, con una pequeña barra de bar, para aquellos osados que buscan tomarse algo fuera de lo común y comerse algo muy innovador y excéntrico, mientras esperan a ser atendidos y ubicados en sus respectivas mesas, por el amable y gentil hostless. En definitiva, una experiencia muy interesante e inolvidable, difícil de olvidar…
</p>

<h3>Reseña histórica</h3>
<p style="text-align: justify;">
En 1994, en la época precolombina, nace el chef deEllio’s Grill & Bakery™, Eliezer Oliveros. Venezolano, criado en un campo ganado, Eliezer Oliveros siempre tuvo como objetivo la idea o el sueño de cumplir una de sus metas: abrir su propio restaurante de comida marítima.<br>
<br>
Pero no fue, sino hasta poco tiempo después, en 2016, cuando su vida dio un giro inesperado. Le sucedió lo que a muchos de nosotros, empresarios y venezolanos nos pasa algún día: Separarse de su familia, y dejarlo todo, su país, su hogar, para forjarse un nuevo destino, y tener lo que muchos de nosotros los venezolanos anhelamos con todo el alma, con todo el corazón: tener un futuro…<br>
<br>
Mas sin embargo, eso no lo detuvo. A pesar de todos los obstáculos que en su vida, en su trayecto para cumplir ese sueño consiguió, actualmente, el chef tiene 22 años, y es uno de los chefs más jóvenes en adentrarse, trascender y progresar en este hermoso y variado mundo de la gastronomía marítima…<br>
<br>
Hoy por hoy, eso es Ellio’s Grill & Bakery™, un restaurante de comida marítima inspirado en eso, en el “Bakery” (panadería o pastelería), en la alta gama de variedad, colores y sabores que los clientes o comensales pueden degustar en sus novedosos, deliciosos e innovadores platillos marinos. Un lugar donde el tiempo trasciende lentamente, donde se destacan los colores típicos de la época precolombina, donde amigos, extraños y familiares pueden trabajar en conjunto. Porque eso es lo que se busca, eso es lo que somos. Juntos, todos somos Ellio’s Grill & Bakery™.
</p>

<h3>Visión</h3>
<p style="text-align: justify;">
Somos una empresa encargada de trascender las fronteras en la alta y variada comida marítima, sirviendo platillos con una alta gama en variedad, sabores y colores que pueda disfrutar y degustar cualquier paladar.
</p>

<h3>Misión</h3>
<p style="text-align: justify;">
Ser reconocidos como una empresa de la mayor gama y variedad de platillos en cuanto a sabores y presentaciones se refiere. Comprometidos con la calidad empresarial y los valores humanos que son los que forman a un gran ciudadano.
</p>
<center><img src="http://i.imgur.com/UKfBlO4.jpg"></center>