<title>Acerca | Elio's Grill & Bakery™</title>

<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'Acerca de nosotros',
);
?>
<h1>Acerca de Nosotros</h1>

<p>
<ul><b>Acerca de Ellio’s Grill & Bakery™</b></ul>
</p>

<h3><div class="span9"><img src="http://i.imgur.com/UKfBlO4.jpg" align="left" width="682" height="384"></div>Ubicación</h3>
<p style="text-align: justify;">
A escasos 200 metros de la estación del metro Bello Monte, la empresa o local de comida marítima Ellio’s Grill & Bakery™ está ubicado en la calle Marilla de Colinas de Los Chaguaramos, entre la quinta transversal, al lado del Centro Polo. Cuenta con un amplio y seguro estacionamiento propio con Valet Parking.<br>
<br>
Al llegar a la entrada, un pequeño pero clásico recibidor acoge a los clientes con unos grandes, hermosos e históricos cuadros pintorescos de la época precolombina. El suelo está rodeado con elegantes, cómodos y modernos sofás alrededor de las paredes. Acompañando el lugar, con una pequeña barra de bar, para aquellos osados que buscan tomarse algo fuera de lo común y comerse algo muy innovador y excéntrico, mientras esperan a ser atendidos y ubicados en sus respectivas mesas, por el amable y gentil hostless. En definitiva, una experiencia muy interesante e inolvidable, difícil de olvidar…
</p>

<ul><h3>Reseña histórica</h3></ul>
<p style="text-align: justify;">
En 1994, en la época precolombina, nace el chef de Ellio’s Grill & Bakery™, Eliezer Oliveros. Venezolano, criado en un campo ganado, Eliezer Oliveros siempre tuvo como objetivo la idea o el sueño de cumplir una de sus metas: abrir su propio restaurante de comida marítima.<br>
<br>
Pero no fue, sino hasta poco tiempo después, en 2016, cuando su vida dio un giro inesperado. Le sucedió lo que a muchos de nosotros, empresarios y venezolanos nos pasa algún día: Separarse de su familia, y dejarlo todo, su país, su hogar, para forjarse un nuevo destino, y tener lo que muchos de nosotros los venezolanos anhelamos con todo el alma, con todo el corazón: tener un futuro…<br>
<br>
Mas sin embargo, eso no lo detuvo. A pesar de todos los obstáculos que en su vida, en su trayecto para cumplir ese sueño consiguió, actualmente, el chef tiene 22 años, y es uno de los chefs más jóvenes en adentrarse, trascender y progresar en este hermoso y variado mundo de la gastronomía marítima…<br>
<br>
Hoy por hoy, eso es Ellio’s Grill & Bakery™, un restaurante de comida marítima inspirado en eso, en el “Bakery” (panadería o pastelería), en la alta gama de variedad, colores y sabores que los clientes o comensales pueden degustar en sus novedosos, deliciosos e innovadores platillos marinos. Un lugar donde el tiempo trasciende lentamente, donde se destacan los colores típicos de la época precolombina, donde amigos, extraños y familiares pueden trabajar en conjunto. Porque eso es lo que se busca, eso es lo que somos. Juntos, todos somos Ellio’s Grill & Bakery™.
</p>

<ul><h3>Visión</h3></ul>
<p style="text-align: justify;">
Somos una empresa encargada de trascender las fronteras en la alta y variada comida marítima, sirviendo platillos con una alta gama en variedad, sabores y colores que pueda disfrutar y degustar cualquier paladar.
</p>

<ul><h3>Misión</h3></ul>
<p style="text-align: justify;">
Ser reconocidos como una empresa de la mayor gama y variedad de platillos en cuanto a sabores y presentaciones se refiere. Comprometidos con la calidad empresarial y los valores humanos que son los que forman a un gran ciudadano.
</p>

 <center>

<div style="width: 100%; position:absolute"><div class="status-msg-outer"><span id="status-message" class="status-msg"><span id="status-message-inner"></span></span></div></div>

<form action="//www.blogger.com/widget?blogID=2059229053428816239" method="POST" name="config"><input type="hidden" name="security_token" value="AOuZoY6OKiZsHo2vvnDsYD0BsGq_QOwMVg:1493827844924"><div class="contents"><input type="hidden" name="widgetId" value="Stats1" id="widgetId">
<input type="hidden" name="action" value="configure">
<input type="hidden" name="widgetType" value="Stats">
<input type="hidden" name="sectionId" value="sidebar-left-1" id="sectionId">

<table border="0">

</div>

<td class="item-form Stats">
<div class="item">

<center>

<big>Actualmente son <b>+1,000,000 clientes satisfechos</b> que confían en nosotros ¡Empieze a pedir ya y compruébelo usted mismo!</big><p></p>

</center>

<center>

<label for="style-graphAndSparkline"><img src="//chart.googleapis.com/chart?cht=lfi&amp;chd=s:ABZDEFGHI110TT4UUTZSSSZZZSSSS&amp;chds=0.0,100.0&amp;chs=75x30&amp;chco=202020c8&amp;chf=bg,s,00000014&amp;chls=2.0,0.0,0.0&amp;chm=B,40404064,0,0.0,0.0" alt=""><span class="counter-wrapper graph-counter-wrapper">

<span class="digit stage-0"><big>7</big><span class="blind-plate"></span></span><span class="digit stage-0"><big>4</big><span class="blind-plate"></span></span><span class="digit stage-0"><big>5</big><span class="blind-plate"></span></span><span class="digit stage-0"><big>0</big><span class="blind-plate"></span></span><span class="digit stage-0"><big>1</big><span class="blind-plate"></span></span><span class="digit stage-0"><big>1</big><span class="blind-plate"></span></span><span class="digit stage-0"><big>0</big><span class="blind-plate"></span></span><span class="digit stage-0"><big>5</big><span class="blind-plate"></span></span> <script>var _uox = _uox || {};(function() {var s=document.createElement("script");
s.src="http://static.usuarios-online.com/uo2.min.js";document.getElementsByTagName("head")[0].appendChild(s);})();</script>
<a href="http://www.usuarios-online.com/es/" data-id="643e87faa4e3cb72d787501f3b2a63db" data-type="default" target="_blank" id="uox_link"></a>

</span></label></div></td>

</center>

</table>

</div>
</form>

<style type="text/css">
        div.item {
          margin-bottom: 15px;
        }
        input, label {
          display: inline-block;
          vertical-align: middle;
        }
        #extraConfigContainer {
          border-top: 1px solid #ebebeb;
          padding-top: 15px;
        }
        #extraConfigContainer input, #extraConfigContainer label {
          vertical-align: top;
        }
        .Stats .counter-wrapper {
          display: inline-block;
          font-size: 24px;
          font-weight: bold;
          height: 30px;
          line-height: 30px;
          vertical-align: top;
          direction: ltr;
        }
        .Stats img {
          margin-right: 10px;
          vertical-align: top;
        }
        .Stats .graph-counter-wrapper {
          color: #FFF;
        }
        .Stats .digit {
          background: url("/img/widgets/stats-flipper.png") no-repeat left !important;
          border: 1px solid #FFF;
          display: inline-block;
          height: 28px;
          line-height: 28px;
          margin-left: -1px;
          position: relative;
          text-align: center;
          width: 22px;
        }
        .Stats .blind-plate {
          border-bottom: 1px solid #FFF;
          border-top: 1px solid #000;
          filter: alpha(opacity=65);
          height: 0px;
          left: 0;
          opacity: 0.65;
          position: absolute;
          top: 13px;
          width: 22px;
        }
        .Stats .stage-0 {
          background-position: 0 0 !important;
        }
        .Stats .stage-1 {
          background-position: -22px 0 !important;
        }
        .Stats .stage-2 {
          background-position: -44px 0 !important;
        }
        .Stats .stage-3 {
          background-position: -66px 0 !important;
        }
        /* TODO(chrisswc): replace the above with a direct injection of stats.css */
</style>