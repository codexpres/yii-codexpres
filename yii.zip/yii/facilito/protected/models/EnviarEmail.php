<?php 

Yii::import('application.extensions.phpmailer.JPhpMailer');

	class EnviarEmail {

		public function Enviar_Email(array $from, array $to, $subject, $message)
		{
			$mail = new JPhpMailer; 
			$mail->IsSMTP(); 
			$mail->SMTPDebug = 1;
			$mail->Host = 'smtp.gmail.com'; 
			$mail->SMTPAuth = true; 
			$mail->SMTPSecure = "ssl"; 
			$mail->Username = 'anderguevaralaw@gmail.com'; 
			$mail->Port = '465'; 
			$mail->Password = 'pwd'; 
			$mail->SetFrom('anderguevaralaw@gmail.com', 'Ander Guevara'); 
			$mail->Subject = 'PHPMailer Test Subject via GMail, basic with authentication'; 
			$mail->AltBody = 'To view the message, please use an HTML compatible email viewer!'; 
			$mail->MsgHTML('JUST A TEST!'); 
			$mail->AddAddress('anderguevaralaw@gmail.com', 'Ander Guevara'); 
			$mail->Send();
		}
	}

?>