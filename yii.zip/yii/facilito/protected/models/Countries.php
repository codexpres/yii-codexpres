<?php
class Countries extends CActiveRecord
{
	public static function model($ClassName=__CLASS__)
	{
		return parent::model($ClassName);
	}

	public function tableName()
	{
		return "countries";
	}

	public function rules()
	{
		return array(
			array("food, name, address, phone", "required"),
			array('specifications, status', 'length', 'max'=>128),
		);
	}
	public function getSelectName()
	{
		return $this->name." ".$this->id." =)";
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'phone' => 'Phone',
			'address' => 'Address',
			'food' => 'Food',
			'specifications' => 'Specifications',
			'status' => 'Status',
		);
	}
}